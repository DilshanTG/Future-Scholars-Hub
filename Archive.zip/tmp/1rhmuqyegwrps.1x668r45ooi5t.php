<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Recordings - Future Scholars Hub</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/css/style.css" rel="stylesheet">
    <style>
        .dashboard-header {
            background: white;
            padding: 1rem 2rem;
            border-radius: 0 0 24px 24px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 2rem;
        }

        .nav-link {
            color: var(--text-color);
            font-weight: 600;
            padding: 0.5rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }

        .recording-card {
            border: none;
            border-radius: 20px;
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
            background: white;
        }

        .recording-card:active {
            transform: scale(0.98);
        }

        .play-icon {
            width: 48px;
            height: 48px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 1rem;
        }
    </style>
</head>

<body>
    <div class="container-fluid px-0">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg dashboard-header">
            <div class="container">
                <a class="navbar-brand fw-bold text-primary fs-4" href="/student/dashboard">🎓 Future Scholars</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto gap-2">
                        <li class="nav-item"><a class="nav-link" href="/student/dashboard">Dashboard 🏠</a></li>
                        <li class="nav-item"><a class="nav-link" href="/student/classes">Classes 📚</a></li>
                        <li class="nav-item"><a class="nav-link active" href="/student/recordings">Recordings 🎥</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="/student/notes">Notes 📝</a></li>
                        <li class="nav-item"><a class="nav-link" href="/student/announcements">News 📢</a></li>
                        <li class="nav-item"><a class="nav-link" href="/student/payment">Payment 💳</a></li>
                        <li class="nav-item"><a class="nav-link" href="/student/profile">Profile 👤</a></li>
                        <li class="nav-item"><a class="nav-link text-danger" href="/logout">Logout 🚪</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container pb-5">
            <h2 class="fw-bold mb-4 px-2">My Recordings 🎥</h2>

            <?php if ($student['status'] != 'active'): ?>
                
                    <div class="alert alert-warning rounded-4 shadow-sm mx-2">
                        <h5 class="alert-heading fw-bold">⚠️ Account Inactive</h5>
                        <p class="mb-0">Your account is inactive. Please contact your teacher to access recordings.</p>
                    </div>
                
            <?php endif; ?>

            <div class="row">
                <?php foreach (($recordings?:[]) as $recording): ?>
                    <div class="col-md-6 mb-3">
                        <a href="<?= ($recording['link']) ?>" target="_blank" class="text-decoration-none">
                            <div class="card recording-card h-100">
                                <div class="card-body p-3 d-flex align-items-center">
                                    <div class="play-icon flex-shrink-0 shadow-sm">
                                        ▶
                                    </div>
                                    <div class="flex-grow-1 overflow-hidden">
                                        <h5 class="card-title fw-bold text-dark mb-1 text-truncate"><?= ($recording['topic']) ?></h5>
                                        <p class="card-text text-muted small mb-0 text-truncate">
                                            <?php if ($recording['description']): ?>
                                                <?= ($recording['description']) ?> • 
                                            <?php endif; ?>
                                            <?= (date('M d, Y', strtotime($recording['created_at'])))."
" ?>
                                        </p>
                                    </div>
                                    <div class="text-primary ms-2">
                                        →
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>

                <?php if (empty($recordings)): ?>
                    
                        <div class="col-12">
                            <div class="alert alert-light text-center py-5 rounded-4 shadow-sm">
                                <div class="fs-1 mb-3">🎬</div>
                                <h4>No recordings yet</h4>
                                <p class="text-muted">Check back later for class recordings!</p>
                            </div>
                        </div>
                    
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>