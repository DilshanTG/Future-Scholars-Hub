<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classes - Future Scholars Hub</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/css/style.css" rel="stylesheet">
    <style>
        .dashboard-header {
            background: white;
            padding: 1rem 2rem;
            border-radius: 0 0 24px 24px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 2rem;
        }

        .nav-link {
            color: var(--text-color);
            font-weight: 600;
            padding: 0.5rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }
    </style>
</head>

<body>
    <div class="container-fluid px-0">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg dashboard-header">
            <div class="container">
                <a class="navbar-brand fw-bold text-primary fs-4" href="/teacher/dashboard">🎓 Future Scholars</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto gap-2">
                        <li class="nav-item"><a class="nav-link" href="/teacher/dashboard">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="/teacher/students">Students 👶</a></li>
                        <li class="nav-item"><a class="nav-link active" href="/teacher/classes">Classes 📚</a></li>
                        <li class="nav-item"><a class="nav-link" href="/teacher/recordings">Recordings 🎥</a></li>
                        <li class="nav-item"><a class="nav-link" href="/teacher/notes">Notes 📝</a></li>
                        <li class="nav-item"><a class="nav-link" href="/teacher/announcements">News 📢</a></li>
                        <li class="nav-item"><a class="nav-link text-danger" href="/logout">Logout 🚪</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container pb-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Class List 📚</h2>
                <div class="d-none d-md-block">
                    <a href="/teacher/classes/add" class="btn btn-primary">Create Class</a>
                    <a href="/teacher/classes/bulk" class="btn btn-info text-white">Bulk Create</a>
                </div>
            </div>

            <!-- Search Bar -->
            <div class="search-bar">
                <input type="text" class="search-input" id="classSearch" placeholder="🔍 Search classes by topic...">
            </div>

            <!-- Desktop Table (Using Cards Grid for Classes on Desktop usually looks better, but sticking to list/table for consistency with request, actually previous was grid, let's keep grid for desktop but make it cleaner) -->
            <!-- Desktop Table -->
            <div class="card shadow-sm desktop-table">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Topic</th>
                                    <th>Date & Time</th>
                                    <th>Students</th>
                                    <th>Zoom Link</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (($classes?:[]) as $class): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold"><?= ($class['topic']) ?></td>
                                        <td>
                                            <div><?= (date('M d, Y', strtotime($class['class_date']))) ?></div>
                                            <div class="small text-muted"><?= (date('H:i', strtotime($class['class_date']))) ?></div>
                                        </td>
                                        <td><span class="badge bg-light text-dark border"><?= ($class['assigned_count']) ?></span></td>
                                        <td>
                                            <?php if ($class['zoom_link']): ?>
                                                
                                                    <a href="<?= ($class['zoom_link']) ?>" target="_blank"
                                                        class="btn btn-sm btn-light">
                                                        🎥 Join
                                                    </a>
                                                
                                                <?php else: ?><span class="text-muted small">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end pe-4">
                                            <div class="btn-group">
                                                <a href="/teacher/classes/edit/<?= ($class['id']) ?>"
                                                    class="btn btn-sm btn-outline-primary">Edit</a>
                                                <a href="/teacher/classes/assign/<?= ($class['id']) ?>"
                                                    class="btn btn-sm btn-primary">Assign</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Mobile Card List -->
            <div class="mobile-card-list mobile-list">
                <?php foreach (($classes?:[]) as $class): ?>
                    <div class="list-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="list-card-title"><?= ($class['topic']) ?></div>
                            <span class="badge bg-light text-dark border"><?= ($class['assigned_count']) ?> 👤</span>
                        </div>

                        <div class="mb-3">
                            <div class="text-muted">
                                📅 <?= (date('M d, Y', strtotime($class['class_date'])))."
" ?>
                                <span class="mx-1">•</span>
                                ⏰ <?= (date('H:i', strtotime($class['class_date'])))."
" ?>
                            </div>
                        </div>

                        <?php if ($class['zoom_link']): ?>
                            
                                <a href="<?= ($class['zoom_link']) ?>" target="_blank"
                                    class="btn btn-light btn-sm w-100 mb-3">
                                    🎥 Join Zoom Meeting
                                </a>
                            
                        <?php endif; ?>

                        <div class="list-card-actions">
                            <a href="/teacher/classes/edit/<?= ($class['id']) ?>"
                                class="btn btn-outline-primary flex-grow-1">Edit</a>
                            <a href="/teacher/classes/assign/<?= ($class['id']) ?>"
                                class="btn btn-primary flex-grow-1">Assign</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Floating Action Button (Mobile) -->
            <div class="fab-container d-md-none">
                <a href="/teacher/classes/add" class="fab-btn">
                    +
                </a>
                <!-- Note: Bulk create is harder to put in FAB, maybe just primary action -->
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('classSearch').addEventListener('keyup', function () {
            let searchText = this.value.toLowerCase();

            // Filter Desktop Table
            let tableRows = document.querySelectorAll('.desktop-table tbody tr');
            tableRows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });

            // Filter Mobile Cards
            let mobileCards = document.querySelectorAll('.mobile-list .list-card');
            mobileCards.forEach(card => {
                let text = card.textContent.toLowerCase();
                card.style.display = text.includes(searchText) ? '' : 'none';
            });
        });
    </script>
</body>

</html>