<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Notes to Student - Future Scholars Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="/teacher/dashboard">🎓 Future Scholars Hub</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/teacher/dashboard">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/teacher/students">Students</a></li>
                    <li class="nav-item"><a class="nav-link" href="/teacher/classes">Classes</a></li>
                    <li class="nav-item"><a class="nav-link" href="/teacher/recordings">Recordings</a></li>
                    <li class="nav-item"><a class="nav-link" href="/teacher/payments">Payments</a></li>
                    <li class="nav-item"><a class="nav-link" href="/teacher/notes">Notes</a></li>
                    <li class="nav-item"><a class="nav-link" href="/teacher/announcements">Announcements</a></li>                    <li class="nav-item"><a class="nav-link" href="/teacher/history">History</a></li>
                    <li class="nav-item"><a class="nav-link" href="/logout">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2 class="mb-4">Assign Notes to Student</h2>
        
        <div class="card mb-3">
            <div class="card-body">
                <h5>Student: <?= ($student['name']) ?></h5>
                <p><strong>Mobile:</strong> <?= ($student['mobile']) ?> | <strong>Grade:</strong> <?= ($student['grade']) ?></p>
            </div>
        </div>
        
        <div class="card">
            <div class="card-body">
                <form method="POST" action="/teacher/students/assign-note/<?= ($student['id']) ?>">
                    <div class="mb-3">
                        <label class="form-label">Select Notes to Assign</label>
                        <div class="border p-3" style="max-height: 400px; overflow-y: auto;">
                            <?php foreach (($notes?:[]) as $note): ?>
                            <div class="card mb-2">
                                <div class="card-body p-2">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="note_ids[]" value="<?= ($note['id']) ?>" 
                                            id="note<?= ($note['id']) ?>" 
                                            <?php if ($note['is_assigned']): ?>checked<?php endif; ?>>
                                        <label class="form-check-label" for="note<?= ($note['id']) ?>">
                                            <strong><?= ($note['title']) ?></strong>
                                            <?php if ($note['link']): ?>
                                                <br><small>Link: <a href="<?= ($note['link']) ?>" target="_blank"><?= ($note['link']) ?></a></small>
                                            <?php endif; ?>
                                            <?php if ($note['details']): ?>
                                                <br><small><?= ($note['details']) ?></small>
                                            <?php endif; ?>
                                            <br><small class="text-muted">Created: <?= (date('M d, Y', strtotime($note['created_at']))) ?></small>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php if (empty($notes)): ?>
                                
                                    <div class="alert alert-info">No notes available. <a href="/teacher/notes/add">Create a note first</a>.</div>
                                
                            <?php endif; ?>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Assignments</button>
                    <a href="/teacher/students" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white text-center py-3 mt-5">
        <div class="container">
            <p class="mb-0">© 2024 Future Scholars Hub. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

